package com.asen.test;

import java.util.Scanner;

public class RescueRegister {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}
