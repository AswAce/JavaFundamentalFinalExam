package com.asen.test;

import java.util.Scanner;

public class CompetitorEntries {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    }
}
